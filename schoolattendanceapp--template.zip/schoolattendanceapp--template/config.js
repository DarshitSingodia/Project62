import firebase from 'firebase'

const firebaseConfig = {
  apiKey: "AIzaSyD4iJ0lr6SYJO9rFp5_HaWYzdBSM_wkHkg",
  authDomain: "attendance-5fc22.firebaseapp.com",
  projectId: "attendance-5fc22",
  storageBucket: "attendance-5fc22.appspot.com",
  messagingSenderId: "103610559529",
  appId: "1:103610559529:web:ee8168c8f4946ab2494038"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

  export default firebase.database()
 

  